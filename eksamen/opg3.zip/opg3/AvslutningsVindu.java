/* 
   --*java*--
   Klasse for aa lage et avslutningsvindu. Faar data fra klassen Spill
*/

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AvslutningsVindu {
}
